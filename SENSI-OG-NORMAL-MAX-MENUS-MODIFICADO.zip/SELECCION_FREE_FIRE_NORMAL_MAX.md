# Selector de Free Fire Normal y Free Fire MAX

- Después de validar una key con rol de parches, la aplicación muestra un selector con el fondo visual SENSI OG.
- Free Fire MAX abre el menú de parches existente, conservando sus controles y comportamiento.
- Free Fire Normal abre una instancia independiente del mismo diseño y categorías.
- El menú Normal no carga ni aplica archivos de parches: sus interruptores son solo visuales y reproducen los audios `opcion_activada.m4a` y `opcion_desactivada.m4a`.
- El botón de apertura de Free Fire Normal muestra un aviso porque no se configuró un esquema de apertura no verificado.
- No se añadieron los archivos `.3105` enviados por separado.
