import Foundation
import CryptoKit

// Offline resources are AES-GCM encrypted. The bundled key is extractable by a
// sufficiently skilled analyst; this is obfuscation, not tamper-proof secrecy.
enum PantherBundledPackages {
    private static let encryptionKey = Data([203, 242, 47, 15, 242, 47, 43, 206, 162, 21, 129, 199, 197, 38, 255, 220, 20, 23, 37, 241, 149, 111, 6, 21, 59, 133, 127, 74, 218, 122, 5, 179])
    private static let packageNames = ["package_0", "package_1", "package_2", "package_3"]

    static func installIfNeeded() {
        for name in packageNames {
            do {
                guard let url = Bundle.main.url(forResource: name, withExtension: "bin") else {
                    log("patch: missing offline resource \(name)")
                    continue
                }
                let encrypted = try Data(contentsOf: url)
                guard encrypted.count > 28 else { continue }
                let nonce = try AES.GCM.Nonce(data: encrypted.prefix(12))
                let ciphertext = encrypted.dropFirst(12)
                let sealed = try AES.GCM.SealedBox(combined: Data(nonce) + ciphertext)
                let clear = try AES.GCM.open(sealed, using: SymmetricKey(data: encryptionKey))
                let summary = try PatchPackageCodec.inspect(clear)
                let existing = PatchProjectLibrary.load().first { $0.id == summary.packageID }
                if existing != nil { continue }
                // Existing .3105 codec performs its own integrity and format checks.
                let decoded = try PatchPackageCodec.decode(clear, password: nil)
                try PatchProjectLibrary.installImportedPackage(
                    data: clear,
                    decoded: decoded,
                    summary: summary,
                    existingURL: nil
                )
            } catch {
                log("patch: offline package installation failed: \(error)")
            }
        }
    }

    // Installs the three bundled Holo packages into the same local library used by
    // the patch manager. Their package contents remain unchanged.
    static func installHoloPackagesIfNeeded() {
        let resources: [(String, String)] = [
            ("HOLO ROSA", "HOLO ROSA"),
            ("HOLO MARI", "HOLO MARI"),
            ("HOLO CELESTE", "HOLO CELESTE"),
            ("HOLO AZUL", "HOLO AZUL")
        ]
        installPlain3105Packages(resources)
    }

    // Installs AIM / body patches for Free Fire Normal menu.
    static func installAimPackagesIfNeeded() {
        let resources: [(String, String)] = [
            ("AIM_HEAD", "AIM HEAD"),
            ("AIM_DRAG", "AIM DRAG"),
            ("Cuello", "AIM CUELLO"),
            ("Pecho", "AIM PECHO")
        ]
        installPlain3105Packages(resources)
    }

    private static func installPlain3105Packages(_ resources: [(String, String)]) {
        guard let root = try? PatchProjectLibrary.packageRootURL() else {
            log("patch: unable to create local package library")
            return
        }
        for (resourceName, destinationName) in resources {
            do {
                let candidates = [
                    resourceName,
                    resourceName.replacingOccurrences(of: "_", with: " "),
                    resourceName.replacingOccurrences(of: " ", with: "_")
                ]
                var source: URL?
                for name in candidates {
                    if let url = Bundle.main.url(forResource: name, withExtension: "3105") {
                        source = url
                        break
                    }
                }
                guard let source else {
                    log("patch: missing bundled resource \(resourceName).3105")
                    continue
                }
                let data = try Data(contentsOf: source)
                // Validar envelope (acepta schema 1...latest)
                _ = try PatchPackageCodec.inspect(data)
                let destination = root
                    .appendingPathComponent(destinationName)
                    .appendingPathExtension("3105")
                // Siempre escribe/actualiza el archivo con el nombre esperado del menú
                try data.write(to: destination, options: [.atomic])
                log("patch: installed/updated \(destinationName).3105")
            } catch {
                log("patch: failed to install \(resourceName): \(error)")
            }
        }
    }
}
